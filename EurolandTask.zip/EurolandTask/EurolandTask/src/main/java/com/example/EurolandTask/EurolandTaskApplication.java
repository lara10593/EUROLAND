package com.example.EurolandTask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.CrossOrigin;


@SpringBootApplication
public class EurolandTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurolandTaskApplication.class, args);
		System.out.println("inside main");
		
	}

}
