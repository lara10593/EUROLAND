package com.example.EurolandTask;

import java.io.File;
import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class HTMLParserJsoup {
	
	@Value("${file_location}")
	private String fileLocation;
	
	@GetMapping("/gethtmldata")
	public String getData()
	{

		System.out.println("inside getData");
		Document htmlFile = null;
		try {
			htmlFile = Jsoup.parse(new File(fileLocation),"ISO-8859-1");
		} catch (IOException e) {
			e.printStackTrace();
		}
		Elements table = htmlFile.getElementsByTag("thead");
		String a = new String();
		String b = new String();

		for (Element t : table) {
			a = t.text().toString();
		}
		String[] a1 = a.split(" ");
		Elements td = htmlFile.getElementsByTag("tbody");
		for (Element t : td) {
			b = t.text().toString();
		}
		String[] b1 = b.split(" ");
		int rowSize = b1.length / a1.length;
		
		// logic to create Json from the data read from HTML
		String[][] result = new String[rowSize + 1][a1.length];
		int count = 0;
		StringBuffer resultString= new StringBuffer();
		resultString.append("["); 
		int firstrow =0;
		for(int k=0;k<a1.length;k++)
		{
			result [firstrow][k] = a1[k];
		}
		for (int i = 1; i < rowSize + 1; i++) {
			resultString.append("{");
			for (int j = 0; j < a1.length; j++) {
				resultString.append("\""+result[0][j]+"\""+":"+"\""+b1[count]+"\"");
				result[i][j] = b1[count];
				count++;
				if(j != a1.length-1)
				resultString.append(",");
			}
			resultString.append("}");
			if(i != rowSize)
			{
				resultString.append(",");
			}
		}
		resultString.append("]");
		
		
		System.out.println(resultString.toString());
						
		return resultString.toString();
	}
	

		
	@GetMapping("/getsize")
	public String getSizeoftherecords()
	{
		Document htmlFile = null;
		try {
			htmlFile = Jsoup.parse(new File(fileLocation),"ISO-8859-1");
		} catch (IOException e) {
			e.printStackTrace();
		}
		String b = null;
		Elements td = htmlFile.getElementsByTag("tbody");
		for (Element t : td) {
			b = t.text().toString();
		}
		String[] b1 = b.split(" ");
		
		int size = b1.length;
		 return "the size of the records is " +size;
	}
	
	
	@GetMapping("/getCountofRowsandColumns")
	public String GetNumberofRowsandColumns()
	{
		Document htmlFile = null;
		try {
			htmlFile = Jsoup.parse(new File(fileLocation),"ISO-8859-1");
		} catch (IOException e) {
			e.printStackTrace();
		}
		Elements table = htmlFile.getElementsByTag("thead");
		String a = new String();
		String b = new String();

		for (Element t : table) {
			a = t.text().toString();
		}
		String[] a1 = a.split(" ");
		Elements td = htmlFile.getElementsByTag("tbody");
		for (Element t : td) {
			b = t.text().toString();
		}
		String[] b1 = b.split(" ");
		int row = b1.length / a1.length;
		int column = a1.length;
		
		StringBuffer result = new StringBuffer();
		result.append("Row size is  : "+row + "   Column size is " +column );  
		 
		return result.toString();
		 
	}
	
	
}
