export class HtmlDataService {

name:String;
class:String;
batch:String;

}
