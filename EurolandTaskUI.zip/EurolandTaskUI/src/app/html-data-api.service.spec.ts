import { TestBed } from '@angular/core/testing';

import { HtmlDataAPIService } from './html-data-api.service';

describe('HtmlDataAPIService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HtmlDataAPIService = TestBed.get(HtmlDataAPIService);
    expect(service).toBeTruthy();
  });
});
