import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HtmlDataService } from './html-data.service';

@Injectable({providedIn: 'root'})

export class  HtmlDataAPIService implements OnInit
{
  url : string="http://localhost:8080/gethtmldata";
 

 
  constructor(private http: HttpClient) { }
  ngOnInit(): void {

  }

getServiceList(): Observable<HtmlDataService[]> 
{
 
  return this.http.get<HtmlDataService[]>(this.url);


    
}
}


